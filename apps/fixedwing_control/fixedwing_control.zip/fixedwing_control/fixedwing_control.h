/****************************************************************************
 * fixedwing_control.h
 *
 *   Copyright (C) 2012 Ivan Ovinnikov. All rights reserved.
 *   Authors: Ivan Ovinnikov <oivan@ethz.ch>
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 3. Neither the name NuttX nor the names of its contributors may be
 *    used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 ****************************************************************************/

/****************************************************************************
 * Included Files
 ****************************************************************************/

#include <nuttx/config.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <debug.h>
#include "../global_data_quad_motors_setpoint_t.h"
#include "../global_data_sensors_raw_t.h"
#include "../global_data_gps_t.h"
#include "../global_data.h"
#include <termios.h>
#include <time.h>
#include <arch/board/up_hrt.h>

/****************************************************************************
 * Public Data
 ****************************************************************************/

/****************************************************************************
 * Internal definitions
 ****************************************************************************/

typedef struct {
	int16_t	gyro_raw[3]; // l3gd20
	int16_t	accelerometer_raw[3]; // bma180
	int16_t	magnetometer_raw[3]; //hmc5883l
	uint32_t pressure_sensor_raw[2]; //ms5611
} sensors_raw_t;

typedef struct {


} data_packet_t;

/****************************************************************************
 * Private Data
 ****************************************************************************/

pthread_t control_thread;

/****************************************************************************
 * Private Functions
 ****************************************************************************/


#ifndef FIXEDWING_CONTROL_H_
#define FIXEDWING_CONTROL_H_



#endif /* FIXEDWING_CONTROL_H_ */
