/****************************************************************************
 * fixedwing_control.c
 *
 *   Copyright (C) 2012 Ivan Ovinnikov. All rights reserved.
 *   Authors: Ivan Ovinnikov <oivan@ethz.ch>
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 3. Neither the name NuttX nor the names of its contributors may be
 *    used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 ****************************************************************************/

/****************************************************************************
 * Included Files
 ****************************************************************************/

#include "fixedwing_control.h"

/****************************************************************************
 * Public Data
 ****************************************************************************/

/****************************************************************************
 * Private Functions
 ****************************************************************************/
int read_sensors_raw(void)
{
	/* TODO */
}

int read_sim_packets{}



static void *control_loop(void * arg)
{
	/* TODO */
}
/****************************************************************************
 * Name: fixedwing_control
 ****************************************************************************/

int fixedwing_control_main(int argc, char *argv[])
{
    // print text
    printf("Hello, Fixedwing Control!\n");
    usleep(100000);

    //default values for arguments
	char * ardrone_uart_name = "/dev/ttyS1";
    char * commandline_usage = "\tusage: ardrone_control -d ardrone-devicename\n";


    //read arguments
	int i;
	if (strcmp(argv[i], "-d") == 0 || strcmp(argv[i], "--device") == 0)  //ardrone set
	{
		if(argc > i+1)
		{
			ardrone_uart_name = argv[i+1];
		}
		else
		{
			printf(commandline_usage);
			return 0;
		}
	}

    /* initialize shared data structures */
	global_data_init(&global_data_gps.access_conf);
	global_data_init(&global_data_sensors_raw.access_conf);
	global_data_init(&global_data_quad_motors_setpoint.access_conf);

	/*open uarts */
	printf("ARDrone UART is %s\n", ardrone_uart_name);
	ardrone_write = open(ardrone_uart_name, O_RDWR | O_NOCTTY | O_NDELAY);

	/* initialize motors */
	ar_init_motors(ardrone_write, &gpios);

	//create pthreads
	pthread_create (&control_thread, NULL, control_loop, NULL);

	//wait for threads to complete:
	pthread_join(control_thread, NULL);

	/* close uarts */
	close(ardrone_uart_name);
	ar_multiplexing_deinit(gpios);



	return 0;
}
